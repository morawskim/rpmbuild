var electron = require('electron'),
    Menu = electron.Menu,
    MenuItem = electron.MenuItem,
    windowManager = require('./windowManager').windowManager,
    path = require('path'),
    _ = require('lodash').noConflict(),
    menuManager = {},
    os = require('os'),
    BrowserWindow = require('electron').BrowserWindow,
    appName = electron.app.getName(),
    osxTopBarMenuTemplate = [
      {
        label: appName,
        submenu: [
          {
            role: 'about'
          },
          {
            label: 'Check for Updates...',
            click: function() { menuManager.handleMenuAction('checkElectronUpdates', null) }
          },
          {
            type: 'separator'
          },
          {
            label: 'Preferences',
            accelerator: 'CmdOrCtrl+,',
            click: function() { menuManager.handleMenuAction('openSettings', null) }
          },
          {
            role: 'services',
            submenu: []
          },
          {
            type: 'separator'
          },
          {
            role: 'hide'
          },
          {
            role: 'hideothers'
          },
          {
            role: 'unhide'
          },
          {
            type: 'separator'
          },
          {
            role: 'quit'
          },
        ]
      },
      {
        label: 'File',
        submenu: [
          {
            label: 'New Tab',
            accelerator: 'CmdOrCtrl+T',
            click: function() { menuManager.handleMenuAction('newTab', null) }
          },
          {
            label: 'New Window',
            accelerator: 'CmdOrCtrl+N',
            click: function() { menuManager.handleMenuAction('newWindow', null) }
          },
          {
            label: 'New Runner Window',
            accelerator: 'CmdOrCtrl+Shift+N',
            click: function() { menuManager.handleMenuAction('openRunner', null) }
          },
          {
            label: 'Open...',
            click: function() { menuManager.handleMenuAction('openImport', null) }
          },
          {
            label: 'Import...',
            accelerator: 'CmdOrCtrl+O',
            click: function() { menuManager.handleMenuAction('openImport', null) }
          },
          {
            type: 'separator'
          },
          {
            label: 'Close Window',
            accelerator: 'CmdOrCtrl+Shift+W',
            click: function() { menuManager.handleMenuAction('closeWindow', null) }
          },
          {
            label: 'Close Tab',
            accelerator: 'CmdOrCtrl+W',
            click: function() { menuManager.handleMenuAction('closeTab', null) }
          },
        ]
      },
      {
        label: 'Edit',
        submenu: [
          {
            role: 'undo'
          },
          {
            role: 'redo'
          },
          {
            type: 'separator'
          },
          {
            role: 'cut'
          },
          {
            role: 'copy'
          },
          {
            role: 'paste'
          },
          {
            role: 'pasteandmatchstyle'
          },
          {
            role: 'delete'
          },
          {
            role: 'selectall'
          }
        ]
      },
      {
        label: 'View',
        submenu: [
          {
            label: 'Reload',
            click: function() {
              menuManager.handleMenuAction('reloadWindow', null)
            }
          },
          {
            role: 'togglefullscreen'
          },
          {
            label: 'Toggle Sidebar',
            accelerator: 'CmdOrCtrl+\\',
            click: function() { menuManager.handleMenuAction('toggleSidebar', null) }
          },
          {
            label: 'Toggle two-pane view',
            accelerator: 'CmdOrCtrl+Alt+V',
            click: function() { menuManager.handleMenuAction('toggleLayout', null) }
          },
          {
            label: 'Show DevTools',
            accelerator: (function() {
              if (process.platform == 'darwin')
                return 'Alt+Command+I';
              else
                return 'Ctrl+Shift+I';
            })(),
            click: function() { menuManager.handleMenuAction('toggleDevTools', null) }
          },
          {
            label: 'Show Postman Console',
            accelerator: 'CmdOrCtrl+Alt+C',
            click: function() {
              menuManager.handleMenuAction('openConsole', null)
            }
          }
        ]
      },
      {
        label: 'Collection',
        submenu: [{
            label: 'New Collection',
            click: function() { menuManager.handleMenuAction('newCollection', null) }
          },
          {
            label: 'Import',
            click: function() { menuManager.handleMenuAction('openImport', null) }
          },
          {
            label: 'Runner',
            click: function() { menuManager.handleMenuAction('openRunner', null) }
          }
        ]
      },
      {
        label: 'History',
        submenu: [
          {
            label: 'No history yet'
          }
        ]
      },
      {
        role: 'window',
        submenu: [
          {
            role: 'minimize'
          },
          {
            role: 'close'
          },
          {
            type: 'separator'
          },
          {
            label: 'Next Tab',
            accelerator: (function () {
              if (process.platform == 'darwin')
                return 'Command+Shift+]';
              else
                return 'Ctrl+Shift+Tab';
            })(),
            click: function() { menuManager.handleMenuAction('nextTab', null) }
          },
          {
            label: 'Previous Tab',
            accelerator: (function () {
              if (process.platform == 'darwin')
                return 'Command+Shift+[';
              else
                return 'Ctrl+Shift+Tab';
            })(),
            click: function() { menuManager.handleMenuAction('previousTab', null) }
          },
          {
            type: 'separator'
          },
          {
            role: 'front'
          },
        ]
      },
      {
        role: 'help',
        submenu: [
          {
            label: 'Documentation',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://www.getpostman.com/docs/") }
          },
          {
            label: 'GitHub',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://github.com/postmanlabs/postman-app-support/") }
          },
          {
            label: 'Twitter',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://twitter.com/postmanclient") }
          },
          {
            label: 'Support',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://getpostman.com/support") }
          }
        ]
      },
    ],
    topBarMenuTemplate = [
      {
        label: 'File',
        submenu: [
          {
            label: 'New Tab',
            accelerator: 'CmdOrCtrl+T',
            click: function() { menuManager.handleMenuAction('newTab', null) }
          },
          {
            label: 'New Window',
            accelerator: 'CmdOrCtrl+N',
            click: function() { menuManager.handleMenuAction('newWindow', null) }
          },
          {
            label: 'New Runner Window',
            accelerator: 'CmdOrCtrl+Shift+N',
            click: function() { menuManager.handleMenuAction('openRunner', null) }
          },
          {
            label: 'Open...',
            click: function() { menuManager.handleMenuAction('openImport', null) }
          },
          {
            label: 'Import...',
            accelerator: 'CmdOrCtrl+O',
            click: function() { menuManager.handleMenuAction('openImport', null) }
          },
          {
            type: 'separator'
          },
          {
            label: 'Settings',
            accelerator: 'CmdOrCtrl+,',
            click: function() { menuManager.handleMenuAction('openSettings', null) }
          },
          {
            type: 'separator'
          },
          {
            label: 'Close Window',
            accelerator: 'CmdOrCtrl+Shift+W',
            click: function() { menuManager.handleMenuAction('closeWindow', null) }
          },
          {
            label: 'Close Tab',
            accelerator: 'CmdOrCtrl+W',
            click: function() { menuManager.handleMenuAction('closeTab', null) }
          },
          {
            role: 'quit'
          },
        ]
      },
      {
        label: 'Edit',
        submenu: [
          {
            role: 'undo'
          },
          {
            role: 'redo'
          },
          {
            type: 'separator'
          },
          {
            role: 'cut'
          },
          {
            role: 'copy'
          },
          {
            role: 'paste'
          },
          {
            role: 'pasteandmatchstyle'
          },
          {
            role: 'delete'
          },
          {
            role: 'selectall'
          }
        ]
      },
      {
        label: 'View',
        submenu: [
          {
            label: 'Reload',
            click: function() { menuManager.handleMenuAction('reloadWindow', null) }
          },
          {
            role: 'togglefullscreen'
          },
          {
            label: 'Toggle Sidebar',
            accelerator: 'CmdOrCtrl+\\',
            click: function() { menuManager.handleMenuAction('toggleSidebar', null) }
          },
          {
            label: 'Toggle two-pane view',
            accelerator: 'CmdOrCtrl+Alt+V',
            click: function() { menuManager.handleMenuAction('toggleLayout', null) }
          },
          {
            label: 'Show DevTools',
            accelerator: (function() {
              if (process.platform == 'darwin')
                return 'Alt+Command+I';
              else
                return 'Ctrl+Shift+I';
            })(),
            click: function() { menuManager.handleMenuAction('toggleDevTools', null) }
          },
          {
            label: 'Show Postman Console',
            accelerator: 'CmdOrCtrl+Alt+C',
            click: function() {
              menuManager.handleMenuAction('openConsole', null);
            }
          }
        ]
      },
      {
        label: 'Collection',
        submenu: [{
            label: 'New Collection',
            click: function() { menuManager.handleMenuAction('newCollection', null) }
          },
          {
            label: 'Import',
            click: function() { menuManager.handleMenuAction('openImport', null) }
          },
          {
            label: 'Runner',
            click: function() { menuManager.handleMenuAction('openRunner', null) }
          }
        ]
      },
      {
        label: 'History',
        submenu: [
          {
            label: 'No history yet'
          }
        ]
      },
      {
        label: 'Help',
        role: 'help',
        submenu: [
          {
            label: 'Check for Updates',
            click: function() { menuManager.handleMenuAction('checkElectronUpdates', null) }
          },
          {
            type: 'separator'
          },
          {
            label: 'Documentation',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://www.getpostman.com/docs/") }
          },
          {
            label: 'GitHub',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://github.com/postmanlabs/postman-app-support/") }
          },
          {
            label: 'Twitter',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://twitter.com/postmanclient") }
          },
          {
            label: 'Support',
            click: function() { menuManager.handleMenuAction('openCustomUrl', "https://getpostman.com/support") }
          }
        ]
      },
    ],
    dockMenuTemplate = [
      { label: 'New Collection', click: function(menuItem) { menuManager.handleMenuAction('newCollection', null) } },
      { label: 'New Window ',  click: function(menuItem) { menuManager.handleMenuAction('newWindow', null) } }
    ];
menuManager = {
  dockMenuTemplate: dockMenuTemplate,

  createMenu: function () {
    Menu.setApplicationMenu(
      Menu.buildFromTemplate(
        this.getMenuBarTemplate()
      )
    );
  },

  getMenuBarTemplate: function() {
    var platform = os.platform();
    if (platform === 'darwin') {
      return osxTopBarMenuTemplate;
    }
    else {
      return topBarMenuTemplate;
    }
  },

  appendHistory: function (items) {
    var menuTemplate = this.getMenuBarTemplate();
    var templateWithoutHistory = _.filter(menuTemplate, function (item) {
      return item.label !== 'History'
    })

    var collectionPosition = _.findIndex(menuTemplate, function (item) {
      return item.label === 'Collection'
    })

    var historySubmenu = _.map(items, function (item) {
      return {
        label: item.method + '  ' + item.url,
        click: function () { menuManager.handleMenuAction('loadHistoryRequest', { requestId: item.id }) }
      }
    })

    templateWithoutHistory.splice(collectionPosition + 1, 0, {
      label: 'History',
      submenu: historySubmenu
    })

    var menu = Menu.buildFromTemplate(templateWithoutHistory)
    Menu.setApplicationMenu(menu);
  },

  handleMenuAction: function(action, meta) {
    if(action === "reloadWindow") {
      var win = BrowserWindow.getFocusedWindow();
      if(win) {
        win.webContents.reloadIgnoringCache();
      }
    }
    else if (action === "newWindow") {
      windowManager.newRequesterWindow();
    }
    else if (action === "toggleDevTools") {
      var win = BrowserWindow.getFocusedWindow();
      if(win) {
        if (win.webContents.isDevToolsOpened()) {
          win.webContents.closeDevTools();
        }
        else {
          if (process.env.PM_BUILD_ENV !== 'development') {
            win.webContents.openDevTools({mode: 'detach'});
          }
          else {
            win.webContents.openDevTools();
          }
        }
      }
    }
    else if(action === "openCustomUrl") {
      windowManager.openCustomURL(meta);
    }
    else if(action == "openConsole") {
      windowManager.newConsoleWindow();
    }
    else if(action === 'newTab') {
      windowManager.sendCustomInternalEvent(action);
    }
    else if(action === 'closeTab') {
      windowManager.sendCustomInternalEvent(action);
    }
    else if(action === 'closeWindow') {
      var win = BrowserWindow.getFocusedWindow();
      win && win.close();
    }
    else if(action === 'nextTab') {
      windowManager.sendCustomInternalEvent(action);
    }
    else if(action === 'previousTab') {
      windowManager.sendCustomInternalEvent(action);
    }
    else if(action === 'loadHistoryRequest') {
      windowManager.sendCustomInternalEvent(action, {
        requestId: meta.requestId
      });
    }
    else {
      windowManager.sendToFirstWindow({
        name: "internalEvent",
        data: {
          event: action
        }
      });
    }
  },
}

exports.menuManager = menuManager;
